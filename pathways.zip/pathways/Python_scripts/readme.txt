jupyter notebook

or for heavy stuff

jupyter notebook --NotebookApp.iopub_data_rate_limit=10000000000


